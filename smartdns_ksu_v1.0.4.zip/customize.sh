#!/system/bin/sh

### SmartDNS KSU模块 - 安装脚本 ###
SKIPUNZIP=1

[ "$BOOTMODE" == 'true' ] || abort "[Error]: 请从KernelSU Manager安装。"

ui_print "- SmartDNS for KernelSU v1.0.4"
ui_print "- 架构: $ARCH"

case $ARCH in
    arm64|aarch64) ;;
    *) abort "[Error]: $ARCH 架构不支持，仅支持 arm64";;
esac

ui_print "- 解压模块文件..."
unzip -o "$ZIPFILE" 'binary/*' -d $MODPATH >&2
unzip -oj "$ZIPFILE" 'common/*' -d $MODPATH >&2
unzip -oj "$ZIPFILE" 'service.sh' -d $MODPATH >&2
unzip -oj "$ZIPFILE" 'module.prop' -d $MODPATH >&2

mkdir -p $MODPATH/system/bin
echo -e "#!/system/bin/sh
exec $MODPATH/command.sh \"\$@\"" > $MODPATH/system/bin/smartdns

ui_print "- 创建配置目录..."
mkdir -p /data/adb/smartdns/config
if [ ! -f /data/adb/smartdns/config/smartdns.conf ]; then
    unzip -oj "$ZIPFILE" 'config/smartdns.conf' -d /data/adb/smartdns/config >&2
    unzip -oj "$ZIPFILE" 'config/script_conf.sh' -d /data/adb/smartdns/config >&2
    ui_print "  配置已初始化 (首次安装)"
else
    ui_print "  保留已有配置"
fi

ui_print "- 设置权限..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/binary/smartdns     0 0 0755
set_perm $MODPATH/command.sh          0 0 0755
set_perm $MODPATH/constant.sh         0 0 0755
set_perm $MODPATH/service.sh          0 0 0755
set_perm $MODPATH/system/bin/smartdns 0 0 0755

chown 0:$(id -g radio 2>/dev/null || echo 1001) /data/adb/smartdns/config 2>/dev/null
chmod 0755 /data/adb/smartdns/config 2>/dev/null

ui_print "- 安装完成!"
ui_print "  配置文件: /data/adb/smartdns/config/smartdns.conf"
