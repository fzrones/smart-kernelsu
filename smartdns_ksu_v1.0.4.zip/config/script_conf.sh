#!/system/bin/sh

### SmartDNS 脚本配置 ###
### 修改前请先停止服务: smartdns stop ###

# 生成脚本日志 [yes|no]
log='no'

# 主要监听端口
Main_PORT='6053'

# 次要监听端口 (WiFi共享代理，为空则使用主端口)
Second_PORT=''

# 工作模式
# local  : 本机DNS重定向
# proxy  : WiFi共享代理
# local,proxy : 两者结合
# server : 仅启动服务
MODE='local'

# 放行 tun 接口数据包 (代理VPN) [yes|no]
TUN='yes'

# 放行 wlan 接口数据包 (WiFi共享时设为yes) [yes|no]
WLAN='no'

# 放行 data 接口数据包 [yes|no]
DATA='no'

# 放行特定应用 (包名或UID，空格分隔)
PKG='com.github.shadowsocks com.v2ray.ang com.github.kr328.clash com.getsurfboard'

# 封锁本机IPv6 DNS查询 [yes|no]
IP6T_BLOCK='yes'