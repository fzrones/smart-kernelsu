#!/system/bin/sh

### SmartDNS KernelSU 模块 - 常量定义 ###
readonly CORE_NAME="smartdns"

# 存储位置
readonly CORE_INTERNAL_DIR="$MODDIR/binary"
readonly DATA_INTERNAL_DIR="/data/adb/$CORE_NAME/config"

# 工作目录 (/dev/smartdns)
readonly WORK_DIR="/dev/$CORE_NAME"
readonly CORE_DIR="$WORK_DIR/binary"
readonly DATA_DIR="$WORK_DIR/config"
LOG_DIR="$WORK_DIR/log"
TEMP_DIR="$WORK_DIR/tmp"

# PID文件
readonly PID_FILE="$TEMP_DIR/server.pid"

# 启动命令
readonly CORE_BOOT="$CORE_NAME -c $DATA_DIR/smartdns.conf -p $PID_FILE"

# 初始化工作环境
initTask() {
    mkdir -p "$CORE_DIR" "$DATA_DIR" "$LOG_DIR" "$TEMP_DIR"
    mount -o bind "$CORE_INTERNAL_DIR" "$CORE_DIR"
    mount -o bind "$DATA_INTERNAL_DIR" "$DATA_DIR"

    # 等待网络就绪（最多等60秒）
    local count='0'
    while true; do
        ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1
        if [ "$?" == '0' ]; then break; fi
        [ ${count} -ge 30 ] && break
        sleep 2; count=$((${count} + 1))
    done
}