#!/system/bin/sh

### SmartDNS KernelSU 模块 - 服务控制脚本 ###

MODDIR=$(realpath $0)
MODDIR=${MODDIR%/*}; cd $MODDIR

. $MODDIR/constant.sh

# 读取脚本配置
SCRIPT_CONF="$DATA_INTERNAL_DIR/script_conf.sh"
[ -f "$SCRIPT_CONF" ] && . "$SCRIPT_CONF"

# 默认值
[ -z "$Main_PORT" ] && Main_PORT='6053'
[ -z "$MODE" ] && MODE='local'
[ -z "$TUN" ] && TUN='yes'
[ -z "$WLAN" ] && WLAN='no'
[ -z "$IP6T_BLOCK" ] && IP6T_BLOCK='yes'
[ -z "$PKG" ] && PKG='com.github.shadowsocks com.v2ray.ang com.github.kr328.clash'

# 自动初始化
[ ! -d "$WORK_DIR" ] && initTask

# === 服务器控制 ===

server_start() {
    PATH="$CORE_DIR:$PATH"
    $CORE_BOOT &
    PATH=${PATH#*:}

    local count='0' PID
    while true; do
        PID="$(pgrep $CORE_NAME)"
        echo "$PID" > $PID_FILE
        if [ -n "$PID" ]; then
            echo "[SmartDNS] 服务启动成功 (PID: $PID)"
            break
        fi
        [ ${count} -ge 30 ] && { echo "[SmartDNS] 服务启动失败"; exit 1; }
        sleep .5; count=$((${count} + 1))
    done
}

server_stop() {
    local PID
    if [ -f "$PID_FILE" ]; then
        for PID in $(pgrep $CORE_NAME); do
            kill -TERM "$PID"
        done
        rm -f "$PID_FILE"
        echo "[SmartDNS] 服务已停止"
    else
        for PID in $(pgrep $CORE_NAME); do
            kill -9 "$PID"
        done
        [ -z "$PID" ] && echo "[SmartDNS] 服务未运行"
    fi
}

server_check() {
    pgrep $CORE_NAME >/dev/null 2>&1 && return 0 || return 1
}

# === iptables控制 (IPv4 Only) ===

iptrules_on() {
    [[ "$MODE" != *'local'* && "$MODE" != *'proxy'* ]] && return 0

    # 创建 dns_redirect 链
    iptables -t nat -N dns_redirect 2>/dev/null

    if [[ "$MODE" == *'local'* ]]; then
        # 放行特定UID (root, radio, 代理应用)
        local uid
        for uid in '0' '1001' $PKG; do
            echo "$uid" | grep -q -i '[a-z]' && uid=$(grep -m1 -i $uid /data/system/packages.list 2>/dev/null | cut -d' ' -f2)
            [ -z "$uid" ] && continue
            iptables -t nat -A dns_redirect -m owner --uid-owner ${uid} -j RETURN 2>/dev/null
        done

        # 放行 tun 接口（代理VPN）
        [ "$TUN" == 'yes' ] && iptables -t nat -A dns_redirect -o tun+ -j RETURN

        # 放行 wlan 接口（WiFi共享）
        [ "$WLAN" == 'yes' ] && iptables -t nat -A dns_redirect -o wlan+ -j RETURN

        # 重定向DNS请求到SmartDNS
        iptables -t nat -A dns_redirect -p udp -j MARK --set-xmark 0x853
        iptables -t nat -A dns_redirect -p udp -j REDIRECT --to-ports ${Main_PORT}
    fi

    if [[ "$MODE" == *'proxy'* ]]; then
        # WiFi共享：将局域网DNS请求重定向到SmartDNS
        local IP
        for IP in $(ip addr show wlan0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1); do
            echo "$IP" | grep -q -E '(^192\.168\.)|(^10\.)|(^172\.(1[6-9]|2[0-9]|3[0-1])\.)' || continue
            iptables -t nat -A PREROUTING -i wlan+ -p udp -d ${IP} --dport 53 -j REDIRECT --to-ports ${Second_PORT:-$Main_PORT}
        done
    fi

    # 将OUTPUT流量引入dns_redirect链
    iptables -t nat -A OUTPUT -p udp --dport 53 -j dns_redirect
    iptables -t nat -A POSTROUTING -p udp -m mark --mark 0x853 -j SNAT --to-source 127.0.0.1

    # IPv6: 封锁53端口
    if [ "$IP6T_BLOCK" == 'yes' ]; then
        ip6tables -t filter -N dns_block 2>/dev/null
        [ "$TUN" == 'yes' ] && ip6tables -t filter -A dns_block -o tun+ -j RETURN 2>/dev/null
        ip6tables -t filter -A dns_block -p udp -j DROP 2>/dev/null
        ip6tables -t filter -A OUTPUT -p udp --dport 53 -j dns_block 2>/dev/null
    fi

    echo "[SmartDNS] iptables规则已加载 (模式: $MODE)"
}

iptrules_off() {
    [[ "$MODE" != *'local'* && "$MODE" != *'proxy'* ]] && return 0

    # 移除IPv4规则
    iptables -t nat -D OUTPUT -p udp --dport 53 -j dns_redirect 2>/dev/null
    iptables -t nat -D POSTROUTING -p udp -m mark --mark 0x853 -j SNAT --to-source 127.0.0.1 2>/dev/null
    iptables -t nat -F dns_redirect 2>/dev/null
    iptables -t nat -X dns_redirect 2>/dev/null

    # 移除IPv6封锁
    if [ "$IP6T_BLOCK" == 'yes' ]; then
        ip6tables -t filter -D OUTPUT -p udp --dport 53 -j dns_block 2>/dev/null
        ip6tables -t filter -F dns_block 2>/dev/null
        ip6tables -t filter -X dns_block 2>/dev/null
    fi

    echo "[SmartDNS] iptables规则已清除"
}

# === 命令处理 ===

case "$1" in
    start)
        server_stop
        iptrules_off
        server_start && iptrules_on
        ;;
    stop)
        iptrules_off
        server_stop
        ;;
    status)
        if server_check; then
            echo "[SmartDNS] 运行中 (端口: $Main_PORT)"
        else
            echo "[SmartDNS] 未运行"
        fi
        ;;
    restart)
        $0 stop
        sleep 1
        $0 start
        ;;
    *)
        echo "用法: smartdns {start|stop|status|restart}"
        echo "  配置文件: /data/adb/smartdns/config/smartdns.conf"
        echo "  脚本配置: /data/adb/smartdns/config/script_conf.sh"
        exit 1
        ;;
esac