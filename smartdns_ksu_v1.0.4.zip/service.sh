#!/system/bin/sh

### SmartDNS KSU模块 - service.sh (开机自启动) ###
MODDIR=${0%/*}
cd $MODDIR

# 延迟启动，等待系统就绪
sleep 5

# 调用 command.sh start（统一入口，含进程+iptables完整流程）
$MODDIR/command.sh start
